<div class="jumbotron">
    <h1>Desculpe!</h1>
    <h3>Nenhum resultado encontrado! <a href="{{ URL::previous() }}">Clique aqui para voltar</a></h3>
</div>

